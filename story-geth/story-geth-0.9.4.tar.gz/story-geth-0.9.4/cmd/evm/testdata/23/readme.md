These files exemplify how to sign a transaction using the pre-EIP155 scheme. 
